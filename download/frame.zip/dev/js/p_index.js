
require(['jq','common','header','carousel'],function(){
	console.log("首页");				
})