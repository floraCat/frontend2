define(['jq'],function(){
	console.log("共用的脚本");
});
