define(['jq'],function(){
	console.log("头部的脚本");
});
