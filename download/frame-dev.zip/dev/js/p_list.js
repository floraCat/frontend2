require(['jq','common','header'],function(){
	console.log("列表页");				
})